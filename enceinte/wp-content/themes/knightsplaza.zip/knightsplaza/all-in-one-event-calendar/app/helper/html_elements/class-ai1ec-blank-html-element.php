<?php
/**
 *
 * @author Timely Network Inc
 *
 * Some times we need to return an html element which is simply blank, output nothing.
 */

class Ai1ec_Blank_Html_Element extends Ai1ec_Html_Element {
	
	/**
	 *
	 * @see Ai1ec_Renderable::render()
	 *
	 */
	public function render() {
	
	}
}