<?php
//
//  class-ai1ec-datetime-exception.php
//  all-in-one-event-calendar
//
//  Created by Timely Network Inc on 2012-10-05.
//

/**
 * Ai1ec_Datetime_Exception class
 *
 * @package Exceptions
 * @author time.ly
 **/
class Ai1ec_Datetime_Exception extends Exception {
}
