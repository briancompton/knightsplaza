<?php

/**
 * @author Timely Network Inc
 *
 *
 */

class Ai1ec_Cache_Write_Exception extends Exception {

}
