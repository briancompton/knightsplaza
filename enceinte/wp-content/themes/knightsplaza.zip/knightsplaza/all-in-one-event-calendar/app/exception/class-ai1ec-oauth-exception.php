<?php

/**
 * OAuth exception
 *
 * @author     Timely Network Inc
 * @since      2013.05.27
 *
 * @package    AllInOneEventCalendar
 * @subpackage AllInOneEventCalendar.App.Exception
 */
class Ai1ec_Oauth_Exception extends Exception {

}
