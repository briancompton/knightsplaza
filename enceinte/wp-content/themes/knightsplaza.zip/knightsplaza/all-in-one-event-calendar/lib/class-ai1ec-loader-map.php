<?php return array (
  'A1iec_Bootstrap_Message' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'bootstrap_helpers' . DIRECTORY_SEPARATOR . 'class-a1iec-bootstrap-message.php',
    ),
  ),
  'Ai1ecFacebookConnectorPlugin' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'Ai1ecFacebookConnectorPlugin.php',
    ),
  ),
  'Ai1ecFileUploadPlugin' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'Ai1ecFileUploadPlugin.php',
    ),
  ),
  'Ai1ecIcsConnectorPlugin' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'Ai1ecIcsConnectorPlugin.php',
    ),
  ),
  'Ai1ec_Abstract_Query' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'adapter' . DIRECTORY_SEPARATOR . 'class-ai1ec-abstract-query.php',
    ),
  ),
  'Ai1ec_Adapter' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'adapter' . DIRECTORY_SEPARATOR . 'class-ai1ec-adapter.php',
    ),
  ),
  'Ai1ec_Adapter_Query_Interface' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'interface' . DIRECTORY_SEPARATOR . 'class-ai1ec-adapter-query-interface.php',
    ),
  ),
  'Ai1ec_Adapter_Query_Wordpress' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'adapter' . DIRECTORY_SEPARATOR . 'class-ai1ec-adapter-query-wordpress.php',
    ),
  ),
  'Ai1ec_Adapters_Factory' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'factory' . DIRECTORY_SEPARATOR . 'class-ai1ec-adapters-factory.php',
    ),
  ),
  'Ai1ec_Admin_Message_Helper' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'admin_notices' . DIRECTORY_SEPARATOR . 'class-ai1ec-admin-message-helper.php',
    ),
  ),
  'Ai1ec_Agenda_Widget' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'view' . DIRECTORY_SEPARATOR . 'admin' . DIRECTORY_SEPARATOR . 'class-ai1ec-agenda-widget.php',
    ),
  ),
  'Ai1ec_Apc_Cache' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'strategy' . DIRECTORY_SEPARATOR . 'cache_strategy' . DIRECTORY_SEPARATOR . 'class-ai1ec-apc-cache.php',
    ),
  ),
  'Ai1ec_App_Controller' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'class-ai1ec-app-controller.php',
    ),
  ),
  'Ai1ec_App_Helper' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'class-ai1ec-app-helper.php',
    ),
  ),
  'Ai1ec_Arguments_Parser' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'class-ai1ec-arguments-parser.php',
    ),
  ),
  'Ai1ec_Author' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'class-ai1ec-author.php',
    ),
  ),
  'Ai1ec_Base_Container' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'abstract' . DIRECTORY_SEPARATOR . 'class-ai1ec-base-container.php',
    ),
  ),
  'Ai1ec_Blank_Html_Element' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'class-ai1ec-blank-html-element.php',
    ),
  ),
  'Ai1ec_Bootstrap_Button' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'bootstrap_helpers' . DIRECTORY_SEPARATOR . 'class-ai1ec-bootstrap-button.php',
    ),
  ),
  'Ai1ec_Bootstrap_Colorpicker' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'bootstrap_helpers' . DIRECTORY_SEPARATOR . 'class-ai1ec-bootstrap-colorpicker.php',
    ),
  ),
  'Ai1ec_Bootstrap_Modal' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'bootstrap_helpers' . DIRECTORY_SEPARATOR . 'class-ai1ec-bootstrap-modal.php',
    ),
  ),
  'Ai1ec_Bootstrap_Radio' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'bootstrap_helpers' . DIRECTORY_SEPARATOR . 'class-ai1ec-bootstrap-radio.php',
    ),
  ),
  'Ai1ec_Bootstrap_Tab' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'bootstrap_helpers' . DIRECTORY_SEPARATOR . 'class-ai1ec-bootstrap-tab.php',
    ),
  ),
  'Ai1ec_Bootstrap_Tabs_Layout' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'bootstrap_helpers' . DIRECTORY_SEPARATOR . 'class-ai1ec-bootstrap-tabs-layout.php',
    ),
  ),
  'Ai1ec_Cache_Not_Set_Exception' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-cache-not-set-exception.php',
    ),
  ),
  'Ai1ec_Cache_Strategy' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'interface' . DIRECTORY_SEPARATOR . 'class-ai1ec-cache-strategy.php',
    ),
  ),
  'Ai1ec_Cache_Write_Exception' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-cache-write-exception.php',
    ),
  ),
  'Ai1ec_Calendar_Controller' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'class-ai1ec-calendar-controller.php',
    ),
  ),
  'Ai1ec_Calendar_Helper' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'class-ai1ec-calendar-helper.php',
    ),
  ),
  'Ai1ec_Calendar_View' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'calendar_view' . DIRECTORY_SEPARATOR . 'abstract' . DIRECTORY_SEPARATOR . 'class-ai1ec-calendar-view.php',
    ),
  ),
  'Ai1ec_Connector_Plugin' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'class-ai1ec-connector-plugin.php',
    ),
  ),
  'Ai1ec_Container' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'interface' . DIRECTORY_SEPARATOR . 'class-ai1ec-container.php',
    ),
  ),
  'Ai1ec_Cookie_Present_Dto' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'dto' . DIRECTORY_SEPARATOR . 'class-ai1ec-cookie-present-dto.php',
    ),
  ),
  'Ai1ec_Cookie_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-cookie-utility.php',
    ),
  ),
  'Ai1ec_Css_Controller' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'class-ai1ec-css-controller.php',
    ),
  ),
  'Ai1ec_Database' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'class-ai1ec-database.php',
    ),
  ),
  'Ai1ec_Database_Applicator' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'class-ai1ec-database-applicator.php',
    ),
  ),
  'Ai1ec_Database_Error' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-database-error.php',
    ),
  ),
  'Ai1ec_Database_Schema' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'class-ai1ec-database-schema.php',
    ),
  ),
  'Ai1ec_Database_Schema_Exception' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-database-schema-exception.php',
    ),
  ),
  'Ai1ec_Date_Time_Zone_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-date-time-zone-utility.php',
    ),
  ),
  'Ai1ec_Datetime_Exception' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-datetime-exception.php',
    ),
  ),
  'Ai1ec_Db_Adapter' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'interface' . DIRECTORY_SEPARATOR . 'class-ai1ec-db-adapter.php',
    ),
  ),
  'Ai1ec_Db_Cache' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'strategy' . DIRECTORY_SEPARATOR . 'cache_strategy' . DIRECTORY_SEPARATOR . 'class-ai1ec-db-cache.php',
    ),
  ),
  'Ai1ec_Deferred_Rendering_Helper' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'class-ai1ec-deferred-rendering-helper.php',
    ),
  ),
  'Ai1ec_Dto_Factory' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'factory' . DIRECTORY_SEPARATOR . 'class-ai1ec-dto-factory.php',
    ),
  ),
  'Ai1ec_Duplicate_Controller' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'class-ai1ec-duplicate-controller.php',
    ),
  ),
  'Ai1ec_Email_Notification' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'notification' . DIRECTORY_SEPARATOR . 'class-ai1ec-email-notification.php',
    ),
  ),
  'Ai1ec_Error_Validating_App_Id_And_Secret' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-error-validating-app-id-and-secret.php',
    ),
  ),
  'Ai1ec_Event' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'class-ai1ec-event.php',
    ),
  ),
  'Ai1ec_Event_Not_Found' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-event-not-found.php',
    ),
  ),
  'Ai1ec_Events_Controller' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'class-ai1ec-events-controller.php',
    ),
  ),
  'Ai1ec_Events_Helper' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'class-ai1ec-events-helper.php',
    ),
  ),
  'Ai1ec_Events_List_Helper' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'class-ai1ec-events-list-helper.php',
    ),
  ),
  'Ai1ec_Exporter' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'class-ai1ec-exporter.php',
    ),
  ),
  'Ai1ec_Exporter_Controller' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'class-ai1ec-exporter-controller.php',
    ),
  ),
  'Ai1ec_Exporter_Helper' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'class-ai1ec-exporter-helper.php',
    ),
  ),
  'Ai1ec_Facebook_Application' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-application.php',
    ),
  ),
  'Ai1ec_Facebook_Current_User' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-current-user.php',
    ),
  ),
  'Ai1ec_Facebook_Custom_Bulk_Action' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-custom-bulk-action.php',
    ),
  ),
  'Ai1ec_Facebook_Data_Converter' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-data-converter.php',
    ),
  ),
  'Ai1ec_Facebook_Db_Exception' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-db-exception.php',
    ),
  ),
  'Ai1ec_Facebook_Event' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-event.php',
    ),
  ),
  'Ai1ec_Facebook_Factory' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'factory' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-factory.php',
    ),
  ),
  'Ai1ec_Facebook_Friends_Sync_Exception' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-friends-sync-exception.php',
    ),
  ),
  'Ai1ec_Facebook_Graph_Object' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-graph-object.php',
    ),
  ),
  'Ai1ec_Facebook_Graph_Object_Collection' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-graph-object-collection.php',
    ),
  ),
  'Ai1ec_Facebook_Group_Query_Events_Strategy' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-group-query-events-strategy.php',
    ),
  ),
  'Ai1ec_Facebook_Group_Sync_Object_From_Facebook_Strategy' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-group-sync-object-from-facebook-strategy.php',
    ),
  ),
  'Ai1ec_Facebook_Page_Sync_Object_From_Facebook_Strategy' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-page-sync-object-from-facebook-strategy.php',
    ),
  ),
  'Ai1ec_Facebook_Proxy' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'proxy' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-proxy.php',
    ),
  ),
  'Ai1ec_Facebook_Query_Abstract' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-query-abstract.php',
    ),
  ),
  'Ai1ec_Facebook_Sync_Object_Abstract' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-sync-object-abstract.php',
    ),
  ),
  'Ai1ec_Facebook_Tab' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-tab.php',
    ),
  ),
  'Ai1ec_Facebook_User_Query_Events_Strategy' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-user-query-events-strategy.php',
    ),
  ),
  'Ai1ec_Facebook_User_Sync_Object_From_Facebook_Strategy' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'class-ai1ec-facebook-user-sync-object-from-facebook-strategy.php',
    ),
  ),
  'Ai1ec_File_Cache' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'strategy' . DIRECTORY_SEPARATOR . 'cache_strategy' . DIRECTORY_SEPARATOR . 'class-ai1ec-file-cache.php',
    ),
  ),
  'Ai1ec_File_Not_Found' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-file-not-found.php',
    ),
  ),
  'Ai1ec_File_Not_Provided' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-file-not-provided.php',
    ),
  ),
  'Ai1ec_Filesystem_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-filesystem-utility.php',
    ),
  ),
  'Ai1ec_Flow_Exception' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-flow-exception.php',
    ),
  ),
  'Ai1ec_Frequency_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-frequency-utility.php',
    ),
  ),
  'Ai1ec_Generic_Html_Tag' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'class-ai1ec-generic-html-tag.php',
    ),
  ),
  'Ai1ec_Helper_Factory' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'factory' . DIRECTORY_SEPARATOR . 'class-ai1ec-helper-factory.php',
    ),
  ),
  'Ai1ec_Href_Helper' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'routing' . DIRECTORY_SEPARATOR . 'class-ai1ec-href-helper.php',
    ),
  ),
  'Ai1ec_Html_Element' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'abstract' . DIRECTORY_SEPARATOR . 'class-ai1ec-html-element.php',
    ),
  ),
  'Ai1ec_Html_Element_Can_Have_Children' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'abstract' . DIRECTORY_SEPARATOR . 'class-ai1ec-html-element-can-have-children.php',
    ),
  ),
  'Ai1ec_Html_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-html-utility.php',
    ),
  ),
  'Ai1ec_Http_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-http-utility.php',
    ),
  ),
  'Ai1ec_Importer' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'class-ai1ec-importer.php',
    ),
  ),
  'Ai1ec_Importer_Controller' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'class-ai1ec-importer-controller.php',
    ),
  ),
  'Ai1ec_Importer_Helper' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'class-ai1ec-importer-helper.php',
    ),
  ),
  'Ai1ec_Importer_Plugin_Helper' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'class-ai1ec-importer-plugin-helper.php',
    ),
  ),
  'Ai1ec_Inflector_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-inflector-utility.php',
    ),
  ),
  'Ai1ec_Input' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'class-ai1ec-input.php',
    ),
  ),
  'Ai1ec_Invalid_Argument' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-invalid-argument.php',
    ),
  ),
  'Ai1ec_Less_Factory' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'factory' . DIRECTORY_SEPARATOR . 'class-ai1ec-less-factory.php',
    ),
  ),
  'Ai1ec_Less_File' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'class-ai1ec-less-file.php',
    ),
  ),
  'Ai1ec_Less_Variable' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'less_variable' . DIRECTORY_SEPARATOR . 'abstract' . DIRECTORY_SEPARATOR . 'class-ai1ec-less-variable.php',
    ),
  ),
  'Ai1ec_Less_Variable_Color' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'less_variables' . DIRECTORY_SEPARATOR . 'class-ai1ec-less-variable-color.php',
    ),
  ),
  'Ai1ec_Less_Variable_Font' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'less_variables' . DIRECTORY_SEPARATOR . 'class-ai1ec-less-variable-font.php',
    ),
  ),
  'Ai1ec_Less_Variable_Size' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'less_variables' . DIRECTORY_SEPARATOR . 'class-ai1ec-less-variable-size.php',
    ),
  ),
  'Ai1ec_Less_Variables_Editing_Page' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'pages' . DIRECTORY_SEPARATOR . 'class-ai1ec-less-variables-editing-page.php',
    ),
  ),
  'Ai1ec_Lessphp_Controller' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'class-ai1ec-lessphp-controller.php',
    ),
  ),
  'Ai1ec_Loader' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'class-ai1ec-loader.php',
    ),
  ),
  'Ai1ec_Locale' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'interface' . DIRECTORY_SEPARATOR . 'class-ai1ec-locale.php',
    ),
  ),
  'Ai1ec_Locale_Wordpress_Adapter' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'adapter' . DIRECTORY_SEPARATOR . 'class-ai1ec-locale-wordpress-adapter.php',
    ),
  ),
  'Ai1ec_Localization_Helper' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'class-ai1ec-localization-helper.php',
    ),
  ),
  'Ai1ec_Log' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'log' . DIRECTORY_SEPARATOR . 'class-ai1ec-log.php',
    ),
  ),
  'Ai1ec_Log_Appender_Wpdb' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'log' . DIRECTORY_SEPARATOR . 'class-ai1ec-log-appender-wpdb.php',
    ),
  ),
  'Ai1ec_Log_Render_Apc' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'log' . DIRECTORY_SEPARATOR . 'class-ai1ec-log-render-apc.php',
    ),
  ),
  'Ai1ec_Logging_Controller' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'class-ai1ec-logging-controller.php',
    ),
  ),
  'Ai1ec_Memory_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-memory-utility.php',
    ),
  ),
  'Ai1ec_Menu_Adapter' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'interface' . DIRECTORY_SEPARATOR . 'class-ai1ec-menu-adapter.php',
    ),
  ),
  'Ai1ec_Meta' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'class-ai1ec-meta.php',
    ),
  ),
  'Ai1ec_Meta_Option' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'class-ai1ec-meta-option.php',
    ),
  ),
  'Ai1ec_Meta_Post' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'class-ai1ec-meta-post.php',
    ),
  ),
  'Ai1ec_Meta_User' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'class-ai1ec-meta-user.php',
    ),
  ),
  'Ai1ec_No_Valid_Facebook_Access_Token' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-no-valid-facebook-access-token.php',
    ),
  ),
  'Ai1ec_Notification' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'notification' . DIRECTORY_SEPARATOR . 'abstract' . DIRECTORY_SEPARATOR . 'class-ai1ec-notification.php',
    ),
  ),
  'Ai1ec_Notification_Controller' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'class-ai1ec-notification-controller.php',
    ),
  ),
  'Ai1ec_Notification_Factory' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'factory' . DIRECTORY_SEPARATOR . 'class-ai1ec-notification-factory.php',
    ),
  ),
  'Ai1ec_Number_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-number-utility.php',
    ),
  ),
  'Ai1ec_Oauth_Controller' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'class-ai1ec-oauth-controller.php',
    ),
  ),
  'Ai1ec_Oauth_Exception' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-oauth-exception.php',
    ),
  ),
  'Ai1ec_Oauth_Provider' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'oauth' . DIRECTORY_SEPARATOR . 'interface-ai1ec-oauth-provider.php',
    ),
  ),
  'Ai1ec_Oauth_Provider_Twitter' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'oauth' . DIRECTORY_SEPARATOR . 'class-ai1ec-oauth-provider-twitter.php',
    ),
  ),
  'Ai1ec_Page' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'page' . DIRECTORY_SEPARATOR . 'abstract' . DIRECTORY_SEPARATOR . 'class-ai1ec-page.php',
    ),
  ),
  'Ai1ec_Page_Factory' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'factory' . DIRECTORY_SEPARATOR . 'class-ai1ec-page-factory.php',
    ),
  ),
  'Ai1ec_Persistence_Context' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'strategy' . DIRECTORY_SEPARATOR . 'class-ai1ec-persistence-context.php',
    ),
  ),
  'Ai1ec_Platform_Controller' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'class-ai1ec-platform-controller.php',
    ),
  ),
  'Ai1ec_Platform_Helper' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'class-ai1ec-platform-helper.php',
    ),
  ),
  'Ai1ec_Render_Entity_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'render' . DIRECTORY_SEPARATOR . 'class-ai1ec-render-entity-utility.php',
    ),
  ),
  'Ai1ec_Render_Filter_Menu_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'render' . DIRECTORY_SEPARATOR . 'class-ai1ec-render-filter-menu-utility.php',
    ),
  ),
  'Ai1ec_Render_Navigation_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'render' . DIRECTORY_SEPARATOR . 'class-ai1ec-render-navigation-utility.php',
    ),
  ),
  'Ai1ec_Render_Renderable_Entity_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'render' . DIRECTORY_SEPARATOR . 'class-ai1ec-render-renderable-utility.php',
    ),
  ),
  'Ai1ec_Renderable' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'interface' . DIRECTORY_SEPARATOR . 'class-ai1ec-renderable.php',
    ),
  ),
  'Ai1ec_Requirejs_Controller' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'class-ai1ec-requirejs-controller.php',
    ),
  ),
  'Ai1ec_Router' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'routing' . DIRECTORY_SEPARATOR . 'class-ai1ec-router.php',
    ),
  ),
  'Ai1ec_Routing_Factory' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'factory' . DIRECTORY_SEPARATOR . 'class-ai1ec-routing-factory.php',
    ),
  ),
  'Ai1ec_Rss_Feed_Controller' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'class-ai1ec-rss-feed-controller.php',
    ),
  ),
  'Ai1ec_Scheduling_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-scheduling-utility.php',
    ),
  ),
  'Ai1ec_Script_Wordpress_Adapter' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'adapter' . DIRECTORY_SEPARATOR . 'class-ai1ec-script-wordpress-adapter.php',
    ),
  ),
  'Ai1ec_Scripts' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'interface' . DIRECTORY_SEPARATOR . 'class-ai1ec-scripts.php',
    ),
  ),
  'Ai1ec_Select' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'html_elements' . DIRECTORY_SEPARATOR . 'class-ai1ec-select.php',
    ),
  ),
  'Ai1ec_Seo_Helper' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'class-ai1ec-seo-helper.php',
    ),
  ),
  'Ai1ec_Session_Model' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'class-ai1ec-session-model.php',
    ),
  ),
  'Ai1ec_Settings' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'class-ai1ec-settings.php',
    ),
  ),
  'Ai1ec_Settings_Controller' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'class-ai1ec-settings-controller.php',
    ),
  ),
  'Ai1ec_Settings_Helper' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'class-ai1ec-settings-helper.php',
    ),
  ),
  'Ai1ec_Shutdown_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-shutdown-utility.php',
    ),
  ),
  'Ai1ec_Singleton_Restriction' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-singleton-restriction.php',
    ),
  ),
  'Ai1ec_Strategies_Factory' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'factory' . DIRECTORY_SEPARATOR . 'class-ai1ec-strategies-factory.php',
    ),
  ),
  'Ai1ec_String_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-string-utility.php',
    ),
  ),
  'Ai1ec_Tax_Meta_Class' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'Tax-meta-class' . DIRECTORY_SEPARATOR . 'class-ai1ec-tax-meta-class.php',
    ),
  ),
  'Ai1ec_Template_Adapter' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'interface' . DIRECTORY_SEPARATOR . 'class-ai1ec-template-adapter.php',
    ),
  ),
  'Ai1ec_Themes_Controller' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'controller' . DIRECTORY_SEPARATOR . 'class-ai1ec-themes-controller.php',
    ),
  ),
  'Ai1ec_Themes_List_Table' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'class-ai1ec-themes-list-table.php',
    ),
  ),
  'Ai1ec_Time_I18n_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-time-i18n-utility.php',
    ),
  ),
  'Ai1ec_Time_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-time-utility.php',
    ),
  ),
  'Ai1ec_Timer' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-timer.php',
    ),
  ),
  'Ai1ec_Too_Early_For_Wp_Script_Exception' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'exception' . DIRECTORY_SEPARATOR . 'class-ai1ec-too-early-for-wp-script-exception.php',
    ),
  ),
  'Ai1ec_TwitterOAuth' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'twitter-php-sdk' . DIRECTORY_SEPARATOR . 'twitteroauth.php',
    ),
  ),
  'Ai1ec_Tzparser' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-tzparser.php',
    ),
  ),
  'Ai1ec_Tzparser_Test' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-tzparser-test.php',
    ),
  ),
  'Ai1ec_Updater' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'class-ai1ec-updater.php',
    ),
  ),
  'Ai1ec_Uri' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'routing' . DIRECTORY_SEPARATOR . 'class-ai1ec-uri.php',
    ),
  ),
  'Ai1ec_Utility_Array' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-utility-array.php',
    ),
  ),
  'Ai1ec_Validation_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-validation-utility.php',
    ),
  ),
  'Ai1ec_View_Factory' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'factory' . DIRECTORY_SEPARATOR . 'class-ai1ec-view-factory.php',
    ),
  ),
  'Ai1ec_View_Helper' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'class-ai1ec-view-helper.php',
    ),
  ),
  'Ai1ec_Void_Cache' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'strategy' . DIRECTORY_SEPARATOR . 'cache_strategy' . DIRECTORY_SEPARATOR . 'class-ai1ec-void-cache.php',
    ),
  ),
  'Ai1ec_Wordpress_Db_Adapter' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'adapter' . DIRECTORY_SEPARATOR . 'class-ai1ec-wordpress-db-adapter.php',
    ),
  ),
  'Ai1ec_Wordpress_Menu_Adapter' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'adapter' . DIRECTORY_SEPARATOR . 'class-ai1ec-wordpress-menu-adapter.php',
    ),
  ),
  'Ai1ec_Wordpress_Template_Adapter' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'adapter' . DIRECTORY_SEPARATOR . 'class-ai1ec-wordpress-template-adapter.php',
    ),
  ),
  'Ai1ec_Wp_Uri_Helper' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'routing' . DIRECTORY_SEPARATOR . 'class-ai1ec-wp-uri-helper.php',
    ),
  ),
  'Ai1ec_XML_Utility' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'utility' . DIRECTORY_SEPARATOR . 'class-ai1ec-xml-utility.php',
    ),
  ),
  'Facebook_WP_Extend_Ai1ec' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'facebook-php-sdk' . DIRECTORY_SEPARATOR . 'class-facebook-wp.php',
    ),
  ),
  'Logger' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'log4php' . DIRECTORY_SEPARATOR . 'Logger.php',
    ),
  ),
  'OAuthConsumer' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'twitter-php-sdk' . DIRECTORY_SEPARATOR . 'OAuth.php',
    ),
  ),
  'OAuthDataStore' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'twitter-php-sdk' . DIRECTORY_SEPARATOR . 'OAuth.php',
    ),
  ),
  'OAuthException' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'twitter-php-sdk' . DIRECTORY_SEPARATOR . 'OAuth.php',
    ),
  ),
  'OAuthRequest' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'twitter-php-sdk' . DIRECTORY_SEPARATOR . 'OAuth.php',
    ),
  ),
  'OAuthServer' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'twitter-php-sdk' . DIRECTORY_SEPARATOR . 'OAuth.php',
    ),
  ),
  'OAuthSignatureMethod' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'twitter-php-sdk' . DIRECTORY_SEPARATOR . 'OAuth.php',
    ),
  ),
  'OAuthSignatureMethod_HMAC_SHA1' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'twitter-php-sdk' . DIRECTORY_SEPARATOR . 'OAuth.php',
    ),
  ),
  'OAuthSignatureMethod_PLAINTEXT' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'twitter-php-sdk' . DIRECTORY_SEPARATOR . 'OAuth.php',
    ),
  ),
  'OAuthSignatureMethod_RSA_SHA1' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'twitter-php-sdk' . DIRECTORY_SEPARATOR . 'OAuth.php',
    ),
  ),
  'OAuthToken' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'twitter-php-sdk' . DIRECTORY_SEPARATOR . 'OAuth.php',
    ),
  ),
  'OAuthUtil' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'twitter-php-sdk' . DIRECTORY_SEPARATOR . 'OAuth.php',
    ),
  ),
  'Query_Events_Strategy_Interface' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'interface' . DIRECTORY_SEPARATOR . 'class-query-events-strategy-interface.php',
    ),
  ),
  'ReCaptchaResponse' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'recaptcha' . DIRECTORY_SEPARATOR . 'recaptchalib.php',
    ),
  ),
  'SG_iCal' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'SG_iCal.php',
    ),
  ),
  'SG_iCalReader' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'SG_iCal.php',
    ),
  ),
  'SG_iCal_Duration' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'SG_iCal_Duration.php',
    ),
  ),
  'SG_iCal_Factory' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'SG_iCal_Factory.php',
    ),
  ),
  'SG_iCal_Freq' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'SG_iCal_Freq.php',
    ),
  ),
  'SG_iCal_Line' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'SG_iCal_Line.php',
    ),
  ),
  'SG_iCal_Parser' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'SG_iCal_Parser.php',
    ),
  ),
  'SG_iCal_Query' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'SG_iCal_Query.php',
    ),
  ),
  'SG_iCal_Recurrence' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'helper' . DIRECTORY_SEPARATOR . 'SG_iCal_Recurrence.php',
    ),
  ),
  'SG_iCal_VCalendar' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'block' . DIRECTORY_SEPARATOR . 'SG_iCal_VCalendar.php',
    ),
  ),
  'SG_iCal_VEvent' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'block' . DIRECTORY_SEPARATOR . 'SG_iCal_VEvent.php',
    ),
  ),
  'SG_iCal_VTimeZone' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'block' . DIRECTORY_SEPARATOR . 'SG_iCal_VTimeZone.php',
    ),
  ),
  'Sync_Objects_From_Facebook_Strategy_Interface' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'plugin' . DIRECTORY_SEPARATOR . 'inc' . DIRECTORY_SEPARATOR . 'facebook' . DIRECTORY_SEPARATOR . 'interface' . DIRECTORY_SEPARATOR . 'class-sync-objects-from-facebook-strategy-interface.php',
    ),
  ),
  'WP_BaseFacebook_Ai1ec' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'facebook-php-sdk' . DIRECTORY_SEPARATOR . 'base_facebook.php',
    ),
  ),
  'WP_FacebookApiException' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'facebook-php-sdk' . DIRECTORY_SEPARATOR . 'base_facebook.php',
    ),
  ),
  'WP_Facebook_Ai1ec' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'facebook-php-sdk' . DIRECTORY_SEPARATOR . 'facebook.php',
    ),
  ),
  'calendarComponent' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'iCalcreator-2.16' . DIRECTORY_SEPARATOR . 'iCalcreator.class.php',
    ),
  ),
  'iCalUtilityFunctions' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'iCalcreator-2.16' . DIRECTORY_SEPARATOR . 'iCalcreator.class.php',
    ),
  ),
  'iCalcnv' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'iCalcnv-3.0' . DIRECTORY_SEPARATOR . 'iCalcnv.class.php',
    ),
  ),
  'lessc' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'lessphp' . DIRECTORY_SEPARATOR . 'lessc.inc.php',
    ),
  ),
  'lessc_formatter_classic' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'lessphp' . DIRECTORY_SEPARATOR . 'lessc.inc.php',
    ),
  ),
  'lessc_formatter_compressed' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'lessphp' . DIRECTORY_SEPARATOR . 'lessc.inc.php',
    ),
  ),
  'lessc_formatter_lessjs' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'lessphp' . DIRECTORY_SEPARATOR . 'lessc.inc.php',
    ),
  ),
  'lessc_parser' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'lessphp' . DIRECTORY_SEPARATOR . 'lessc.inc.php',
    ),
  ),
  'valarm' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'iCalcreator-2.16' . DIRECTORY_SEPARATOR . 'iCalcreator.class.php',
    ),
  ),
  'vcalendar' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'iCalcreator-2.16' . DIRECTORY_SEPARATOR . 'iCalcreator.class.php',
    ),
  ),
  'vevent' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'iCalcreator-2.16' . DIRECTORY_SEPARATOR . 'iCalcreator.class.php',
    ),
  ),
  'vfreebusy' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'iCalcreator-2.16' . DIRECTORY_SEPARATOR . 'iCalcreator.class.php',
    ),
  ),
  'vjournal' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'iCalcreator-2.16' . DIRECTORY_SEPARATOR . 'iCalcreator.class.php',
    ),
  ),
  'vtimezone' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'iCalcreator-2.16' . DIRECTORY_SEPARATOR . 'iCalcreator.class.php',
    ),
  ),
  'vtodo' => 
  array (
    0 => 
    array (
      0 => '0',
      1 => AI1EC_PATH . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'iCal' . DIRECTORY_SEPARATOR . 'iCalcreator-2.16' . DIRECTORY_SEPARATOR . 'iCalcreator.class.php',
    ),
  ),
);