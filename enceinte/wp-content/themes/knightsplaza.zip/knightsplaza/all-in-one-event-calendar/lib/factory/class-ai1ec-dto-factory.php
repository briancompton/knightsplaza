<?php

/**
 * @author Timely Network Inc
 */

class Ai1ec_Dto_Factory {

	/**
	 * @return Ai1ec_Cookie_Present_Dto
	 */
	static public function create_cookie_present_dto_instance() {
		return new Ai1ec_Cookie_Present_Dto();
	}
}